#define LOGSS 		1
#define UNEXIST 	2
#define PSWRO		3
#define REOK		4
#define REFAIL		5
#define FIEXIST 	6
#define FINEXIST	7
#define FITROVER	8
#define VEROK		9
#define VERFAIL		10



void routine(void *arg);
